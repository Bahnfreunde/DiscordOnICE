
rootProject.name = "DiscordOnICE"

